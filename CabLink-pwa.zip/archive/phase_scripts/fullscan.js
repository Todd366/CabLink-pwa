const fs=require("fs");
const {execSync}=require("child_process");

const files=execSync('find . -type f \\( -name "*.html" -o -name "*.js" \\)')
.toString()
.trim()
.split("\n");

console.log("\n========== CABLINK FORENSIC SCAN ==========\n");

const words=[
"showScreen",
'id="driver"',
'id="profile"',
"STATE",
"role.js",
"function showScreen",
"localStorage",
"bookRide"
];

files.forEach(file=>{
    try{
        const txt=fs.readFileSync(file,"utf8");
        let score=0;

        words.forEach(w=>{
            if(txt.includes(w)) score++;
        });

        if(score){
            console.log(score.toString().padStart(2," "),file);
        }
    }catch(e){}
});

console.log("\n===========================================\n");
