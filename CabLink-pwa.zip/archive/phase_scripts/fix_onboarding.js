const fs = require("fs");

const file = "index.html";
let html = fs.readFileSync(file, "utf8");

html = html.replace(
/#onboarding\s*\{[^}]*\}/,
`#onboarding{
display:none;
position:fixed;
inset:0;
background:#0a0a0f!important;
opacity:1!important;
z-index:99999!important;
flex-direction:column;
align-items:center;
justify-content:center;
padding:32px 24px;
text-align:center;
}`
);

fs.writeFileSync(file, html);

console.log("✅ Onboarding overlay fixed.");
