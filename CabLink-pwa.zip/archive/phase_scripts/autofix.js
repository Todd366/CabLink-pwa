const fs = require("fs");

console.log("\n========== CabLink AutoFix ==========\n");

const backup = f => {
  if (fs.existsSync(f)) {
    fs.copyFileSync(f, `${f}.autobak`);
    console.log("✓ Backup:", f);
  }
};

["index.html","fix.js","role.js","frontend/js/app.js","frontend/js/core.js"]
.forEach(backup);

if (!fs.existsSync("index.html")) {
  console.log("❌ index.html missing");
  process.exit(1);
}

let html = fs.readFileSync("index.html","utf8");

// Ensure scripts are loaded
const scripts = [
  '<script src="frontend/js/app.js"></script>',
  '<script src="frontend/js/core.js"></script>',
  '<script src="fix.js"></script>',
  '<script src="role.js"></script>'
];

scripts.forEach(script=>{
  if(!html.includes(script)){
    html = html.replace("</body>", script + "\n</body>");
    console.log("➕ Added", script);
  }
});

// Navbar background fix
if(!html.includes("#nav{position:absolute")){
  console.log("ℹ Navbar CSS not found (skipped)");
}else{
  html = html.replace(
    "#nav{position:absolute;",
    "#nav{position:absolute;background:var(--bg2)!important;"
  );
  console.log("✓ Navbar background fixed");
}

// Hide demo UI
[
'id="simBtn"',
'id="driverCount"'
].forEach(id=>{
  if(html.includes(id) && !html.includes(id+' style="display:none')){
    html = html.replace(
      id,
      id+' style="display:none!important"'
    );
    console.log("✓ Hid",id);
  }
});

fs.writeFileSync("index.html",html);

// Report
console.log("\n===== PROJECT STATUS =====");

const report = {
  roleJS : html.includes("role.js"),
  fixJS  : html.includes("fix.js"),
  appJS  : html.includes("frontend/js/app.js"),
  coreJS : html.includes("frontend/js/core.js"),
  home   : html.includes('id="s-home"'),
  rewards: html.includes('id="s-rewards"'),
  driver : html.includes('id="s-driver"'),
  profile: html.includes('id="s-profile"'),
  more   : html.includes('id="s-more"'),
  nav    : html.includes('id="nav"'),
  showScreen : html.includes("function showScreen")
};

Object.entries(report).forEach(([k,v])=>{
  console.log(v ? "✅" : "❌", k);
});

console.log("\n========== DONE ==========");
