const fs=require("fs");

let html=fs.readFileSync("index.html","utf8");

if(html.includes("role.js")){
    console.log("✅ role.js already loaded");
    process.exit(0);
}

const target='<script src="fix.js"></script>';

if(html.includes(target)){
    html=html.replace(
        target,
        target+'\n<script src="role.js"></script>'
    );

    fs.writeFileSync("index.html",html);

    console.log("✅ role.js injected");
}else{
    console.log("❌ Couldn't find fix.js script tag");
}
