const fs = require("fs");

const file = "index.html";
let html = fs.readFileSync(file, "utf8");

html = html.replace(
/#nav\s*\{[^}]*\}/,
`#nav{
position:fixed;
bottom:0;
left:0;
right:0;
z-index:9999;
background:#12121a;
border-top:1px solid #2a2a3e;
display:flex;
align-items:flex-end;
padding-bottom:env(safe-area-inset-bottom);
}`
);

fs.writeFileSync(file, html);

console.log("✅ Original #nav CSS replaced with fixed navbar.");
