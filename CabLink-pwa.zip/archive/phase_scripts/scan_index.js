const fs=require("fs");
const {execSync}=require("child_process");

const files=execSync('find . -name "index*.html"')
.toString()
.trim()
.split("\n");

console.log("\n===== INDEX AUDIT =====\n");

files.forEach(file=>{
    const html=fs.readFileSync(file,"utf8");

    const report={
        role:html.includes("role.js"),
        driver:html.includes('id="driver"'),
        profile:html.includes('id="profile"'),
        nav:html.includes('id="nav"'),
        fix:html.includes("fix.js")
    };

    console.log(file);
    console.log(report);
    console.log("-------------------------");
});
