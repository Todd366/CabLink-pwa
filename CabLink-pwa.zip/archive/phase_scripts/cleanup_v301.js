const fs = require("fs");

console.log("🔥 CabLink v301 Automated Cleanup Starting");

const file = "index.html";

let html = fs.readFileSync(file,"utf8");

const backup = `index_backup_before_cleanup_${Date.now()}.html`;

fs.writeFileSync(backup,html);

console.log("✅ Backup created:",backup);


// Remove only visible fake/demo labels
const removeTexts = [
"🧪 Simulate Ride (Test Mode)",
"📡 3 drivers nearby",
"📡 4 drivers nearby",
"⭐ Quick Favourites",
"🕐 Recent Rides"
];


removeTexts.forEach(text=>{
    if(html.includes(text)){
        console.log("Removing:",text);
        html = html.replace(text,"");
    }
});


// Hide demo buttons safely
html = html.replace(
'id="simBtn"',
'id="simBtn" style="display:none!important"'
);


// Hide fake driver count only
html = html.replace(
'id="driverCount"',
'id="driverCount" style="display:none!important"'
);


// Save
fs.writeFileSync(file,html);

console.log("✅ Cleanup complete");
console.log("🔥 CabLink v301 ready for testing");

