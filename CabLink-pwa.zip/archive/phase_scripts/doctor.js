const fs = require("fs");

console.log("\n========== CabLink Doctor ==========\n");

const html = fs.readFileSync("index.html","utf8");

const checks = [
{
name:"role.js loaded",
test:/role\.js/
},
{
name:"fix.js loaded",
test:/fix\.js/
},
{
name:"app.js loaded",
test:/frontend\/js\/app\.js/
},
{
name:"core.js loaded",
test:/frontend\/js\/core\.js/
},
{
name:"bottom nav exists",
test:/id="nav"/
},
{
name:"driver screen",
test:/id="driver"/
},
{
name:"profile screen",
test:/id="profile"/
},
{
name:"CSS variable bg2",
test:/--bg2/
}
];

checks.forEach(c=>{
console.log(
(c.test.test(html)?"✅":"❌"),
c.name
);
});

console.log("\n========== Done ==========");
