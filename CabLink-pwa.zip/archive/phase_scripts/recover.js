const fs = require('fs');

function restore(src,dst){
    if(fs.existsSync(src)){
        fs.copyFileSync(src,dst);
        console.log("✓ Restored",dst);
    }else{
        console.log("✗ Missing",src);
    }
}

console.log("\n===== CabLink Recovery =====\n");

// Restore stable JS
restore(
"recovery_backup_20260713_110611/CabLink-pwa/frontend/js/app.js",
"frontend/js/app.js"
);

restore(
"recovery_backup_20260713_110611/CabLink-pwa/frontend/js/core.js",
"frontend/js/core.js"
);

// Restore stable HTML if available
const backups=fs.readdirSync(".")
.filter(f=>/^index_backup_before_cleanup_.*\.html$/.test(f))
.sort();

if(backups.length){
    const latest=backups[backups.length-1];
    restore(latest,"index.html");
}

// Verify important files
[
"index.html",
"fix.js",
"role.js",
"frontend/js/app.js",
"frontend/js/core.js",
"manifest.json",
"sw.js"
].forEach(f=>{
    console.log(
        fs.existsSync(f)
        ? "✓ "+f
        : "✗ "+f
    );
});

console.log("\nRecovery complete.");
console.log("Run:");
console.log("serve");

