const fs = require("fs");

const file = "index.html";

if (!fs.existsSync(file)) {
    console.log("❌ index.html not found");
    process.exit(1);
}

let html = fs.readFileSync(file, "utf8");

const css = `
<style id="cablink-navbar-fix">
#nav{
position:fixed!important;
bottom:0!important;
left:0!important;
right:0!important;
z-index:9999!important;
background:#12121a!important;
border-top:1px solid #2a2a3e!important;
backdrop-filter:none!important;
opacity:1!important;
}

.screen{
padding-bottom:82px!important;
}
</style>
`;

if (!html.includes("cablink-navbar-fix")) {
    html = html.replace("</head>", css + "\n</head>");
    fs.writeFileSync(file, html);
    console.log("✅ Navbar fix injected.");
} else {
    console.log("✅ Navbar fix already present.");
}
