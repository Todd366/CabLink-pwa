const fs=require("fs");

["frontend/js/app.js","frontend/js/core.js","role.js"].forEach(file=>{
  console.log("\n===== "+file+" =====");

  if(!fs.existsSync(file)){
    console.log("MISSING");
    return;
  }

  const txt=fs.readFileSync(file,"utf8");

  const checks=[
    "showScreen",
    "bookRide",
    "driver",
    "profile",
    "role",
    "STATE",
    "localStorage"
  ];

  checks.forEach(c=>{
    console.log(
      txt.includes(c) ? "✅" : "❌",
      c
    );
  });
});
