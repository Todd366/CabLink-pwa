

export default function StatusCard({title,value}){

return (

<div>

<h3>{title}</h3>

<p>{value}</p>

</div>

);

}

